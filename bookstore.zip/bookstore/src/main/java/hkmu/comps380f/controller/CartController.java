package hkmu.comps380f.controller;


import hkmu.comps380f.model.ShoppingCart;
import hkmu.comps380f.model.Ticket;
import hkmu.comps380f.dao.TicketRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private TicketRepository ticketRepository;

    @PostMapping("/add")
    public String addToCart(@RequestParam("bookId") long bookId, HttpSession session) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }
        Ticket book = ticketRepository.findById(bookId).orElse(null);
        if (book != null) {
            cart.addItem(book);
        }
        return "redirect:/cart/view";
    }

    @GetMapping("/view")
    public String viewCart(HttpSession session, Model model) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart == null) {
            cart = new ShoppingCart();
            session.setAttribute("cart", cart);
        }
        model.addAttribute("cart", cart);
        return "cart";

    }

    @PostMapping("/remove")
    public String removeCartItem(@RequestParam("bookId") long bookId, HttpSession session) {
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
        if (cart != null) {
            cart.removeItem(bookId);
        }
        return "redirect:/cart/view";
    }
}