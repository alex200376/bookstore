package hkmu.comps380f.model;

import java.util.HashMap;
import java.util.Map;

public class ShoppingCart {
    private Map<Long, CartItem> items = new HashMap<>();

    public void addItem(Ticket book) {
        if (items.containsKey(book.getId())) {
            items.get(book.getId()).incrementQuantity();
        } else {
            CartItem newItem = new CartItem(book);
            items.put(book.getId(), newItem);
        }
    }

    public void removeItem(long bookId) {
        // This will remove the item from the map by its key (bookId)
        items.remove(bookId);
    }
    public CartItem findItem(long bookId) {
        return items.get(bookId); // Just return the CartItem associated with bookId
    }
    public Map<Long, CartItem> getItems() {
        return items;
    }


}