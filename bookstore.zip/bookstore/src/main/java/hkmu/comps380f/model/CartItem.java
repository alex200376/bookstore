package hkmu.comps380f.model;

public class CartItem {
    private Ticket book;
    private int quantity;

    // Constructors, getters, and setters
    public CartItem(Ticket book) {
        this.book = book;
        this.quantity = 1;
    }

    public Ticket getBook() {
        return book;
    }

    public void setBook(Ticket book) {
        this.book = book;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void incrementQuantity() {
        this.quantity++;
    }
}