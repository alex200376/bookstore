package hkmu.comps380f;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CSAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
